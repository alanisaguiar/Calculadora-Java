package Calculadora;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class Logging {

    @Pointcut("execution(* Calculadora.Calculadora.*(..))")
    public void capturarMetodosCalculo() {}

    @Before("capturarMetodosCalculo()")
    public void logBefore(JoinPoint joinPoint) {
        Object[] valores = joinPoint.getArgs();
        System.out.println("Operação de " + joinPoint.getSignature().getName() +
                           " realizada com os valores " + valores[0] + " e " + valores[1]);
    }
}

