package Calculadora;

public class Main {
    public static void main(String[] args) {
        Calculadora calculo = new Calculadora();
        
        calculo.somar(5,4, 2);
        calculo.subtrair(30, 5);
        calculo.multiplicar(9, 9);
        calculo.dividir(6,2);
        
    }
}
